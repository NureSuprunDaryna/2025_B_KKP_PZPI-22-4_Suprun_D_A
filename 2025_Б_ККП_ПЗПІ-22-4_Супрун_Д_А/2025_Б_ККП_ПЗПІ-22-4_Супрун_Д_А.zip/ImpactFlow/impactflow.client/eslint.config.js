export default [

  {

    files: ['**/*.js', '**/*.jsx'],

    rules: {

      semi: ['error', 'always'],

      quotes: ['error', 'double'],

    },

  },

];
