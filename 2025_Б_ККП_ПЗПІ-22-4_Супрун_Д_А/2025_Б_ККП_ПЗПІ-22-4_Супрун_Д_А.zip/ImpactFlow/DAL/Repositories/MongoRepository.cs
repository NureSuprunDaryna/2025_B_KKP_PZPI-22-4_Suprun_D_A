﻿using DAL.Context;
using MongoDB.Driver;

namespace DAL.Repositories
{
    public class MongoRepository<T> : IRepository<T> where T : class
    {
        protected readonly IMongoCollection<T> _collection;

        public MongoRepository(MongoContext context, string collectionName)
        {
            _collection = context.GetCollection<T>(collectionName);
        }

        public async Task<T?> GetByIdAsync(string id) =>
            await _collection.Find(x => x.GetType().GetProperty("Id")!.GetValue(x)!.ToString() == id).FirstOrDefaultAsync();

        public async Task<List<T>> GetAllAsync() =>
            await _collection.Find(_ => true).ToListAsync();

        public async Task<List<T>> FindAsync(Func<T, bool> predicate) =>
            await Task.Run(() => _collection.AsQueryable().Where(predicate).ToList());

        public async Task AddAsync(T entity) =>
            await _collection.InsertOneAsync(entity);

        public async Task UpdateAsync(string id, T entity) =>
            await _collection.ReplaceOneAsync(x => x.GetType().GetProperty("Id")!.GetValue(x)!.ToString() == id, entity);

        public async Task DeleteAsync(string id) =>
            await _collection.DeleteOneAsync(x => x.GetType().GetProperty("Id")!.GetValue(x)!.ToString() == id);
    }
}
