﻿namespace Core.Models
{
    public class VolunteerProfile
    {
        public string? Bio { get; set; }
        public string? Phone { get; set; }
        public string? Telegram { get; set; }
        public string? City { get; set; }
        public string? AvatarUrl { get; set; }
    }
}
