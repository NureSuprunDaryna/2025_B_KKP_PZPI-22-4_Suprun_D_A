﻿namespace Core.Models
{
    public class AvailabilitySlot
    {
        public DayOfWeek Day { get; set; }
        public TimeSpan Start { get; set; }
        public TimeSpan End { get; set; }
        public bool IsAvailable { get; set; }
        public bool IsRecurring { get; set; }
    }
}
