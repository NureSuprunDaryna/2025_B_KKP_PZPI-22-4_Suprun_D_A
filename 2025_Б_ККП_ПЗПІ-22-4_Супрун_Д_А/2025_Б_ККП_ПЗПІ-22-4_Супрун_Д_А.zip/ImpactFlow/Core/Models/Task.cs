﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Core.Models
{
    public class Task
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [BsonElement("projectId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string ProjectId { get; set; } = null!;

        [BsonElement("eventId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? EventId { get; set; }

        [BsonElement("title")]
        public string Title { get; set; } = null!;

        [BsonElement("description")]
        public string Description { get; set; } = null!;

        [BsonElement("deadline")]
        public DateTime Deadline { get; set; }

        [BsonElement("status")]
        [BsonRepresentation(BsonType.String)]
        public Core.Enums.TaskStatus Status { get; set; } = Core.Enums.TaskStatus.Pending;

        [BsonElement("points")]
        public int Points { get; set; }

        [BsonElement("assignedToUserId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? AssignedToUserId { get; set; }

        [BsonElement("skillIds")]
        [BsonIgnoreIfNull]
        public List<string>? SkillIds { get; set; }
    }
}
