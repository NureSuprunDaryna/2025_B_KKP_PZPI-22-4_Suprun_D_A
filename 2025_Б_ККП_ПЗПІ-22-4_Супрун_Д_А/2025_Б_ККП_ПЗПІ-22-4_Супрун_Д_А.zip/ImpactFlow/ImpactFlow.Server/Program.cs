using System.Text;
using Core.Configurations;
using Core.Helpers;
using Cyrillic.Convert;
using DAL.Context;
using DAL.Repositories;
using ImpactFlow.DAL.Settings;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

namespace ImpactFlow.Server;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // ===== Controllers + JSON config =====
        builder.Services.AddControllers()
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
                options.JsonSerializerOptions.WriteIndented = true;
            });

        // ===== Swagger =====
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "ImpactFlow API",
                Version = "v1",
                Description = "API for coordinating volunteer initiatives"
            });
        });

        // ===== CORS =====
        builder.Services.AddCors(options =>
        {
            options.AddPolicy("AllowFrontendApp", policy =>
            {
                policy.WithOrigins("https://localhost:5173")
                      .AllowAnyHeader()
                      .AllowAnyMethod()
                      .AllowCredentials();
            });
        });

        // ===== MongoDB Settings =====
        builder.Services.Configure<MongoDbSettings>(
            builder.Configuration.GetSection("MongoDbSettings"));

        // ===== JWT Settings =====
        builder.Services.Configure<JwtSettings>(
            builder.Configuration.GetSection("JwtSettings"));

        // ===== DI for Repositories & Services =====
        builder.Services.AddScoped(typeof(IRepository<>), typeof(MongoRepository<>));
        builder.Services.AddScoped(typeof(UnitOfWork));
        builder.Services.AddScoped(typeof(Conversion));


        builder.Services.AddSingleton<MongoContext>();

        builder.Services.AddAutoMapper(typeof(Program));
        builder.Services.AddScoped<JwtTokenGenerator>();
        builder.Services.AddAuthentication("Bearer")
        .AddJwtBearer("Bearer", options =>
        {
            var jwtSettings = builder.Configuration.GetSection("JwtSettings").Get<JwtSettings>();

            options.Events = new JwtBearerEvents
            {
                OnMessageReceived = context =>
                {
                    if (context.Request.Cookies.ContainsKey("jwt"))
                    {
                        context.Token = context.Request.Cookies["jwt"];
                    }

                    return Task.CompletedTask;
                }
            };

            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = jwtSettings.Issuer,

                ValidateAudience = true,
                ValidAudience = jwtSettings.Audience,

                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero,

                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(jwtSettings.SecretKey))
            };
        });


        var app = builder.Build();

        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "ImpactFlow API");
                c.RoutePrefix = string.Empty; // відкривати Swagger як root page "/"

                c.InjectJavascript("/swagger/token-injector.js");
            });
        }

        app.UseHttpsRedirection();

        app.UseAuthentication(); // TODO: JWT
        app.UseCors("AllowFrontendApp");
        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}
