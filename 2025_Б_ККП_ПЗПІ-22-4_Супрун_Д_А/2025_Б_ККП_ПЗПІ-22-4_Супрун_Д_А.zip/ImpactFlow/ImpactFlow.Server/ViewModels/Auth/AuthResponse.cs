﻿namespace ImpactFlow.Server.ViewModels.Auth
{
    public class AuthResponse
    {
        public string Token { get; set; } = null!;
        public string UserId { get; set; } = null!;
        public string Role { get; set; } = null!;
    }
}
