﻿using AutoMapper;
using Core.Models;
using ImpactFlow.Server.ViewModels.Auth;

namespace ImpactFlow.Server.Mappings;

public class AuthMappingProfile : Profile
{
    public AuthMappingProfile()
    {
        CreateMap<RegisterRequest, User>()
            .ForMember(dest => dest.PasswordHash, opt => opt.Ignore())
            .ForMember(dest => dest.RegisteredAt, opt => opt.Ignore())
            .ForMember(dest => dest.Role, opt => opt.Ignore())
            .ForMember(dest => dest.Availability, opt => opt.Ignore())
            .ForMember(dest => dest.Profile, opt => opt.Ignore());
    }
}
