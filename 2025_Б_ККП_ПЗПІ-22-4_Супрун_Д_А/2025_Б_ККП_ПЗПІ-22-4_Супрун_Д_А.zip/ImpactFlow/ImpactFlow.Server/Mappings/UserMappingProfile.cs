﻿using AutoMapper;
using Core.Models;
using ImpactFlow.Server.ViewModels.User;

namespace ImpactFlow.Server.Mappings
{
    public class UserMappingProfile : Profile
    {
        public UserMappingProfile()
        {
            CreateMap<User, UserViewModel>()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => src.Role.ToString()));
        }
    }
}
