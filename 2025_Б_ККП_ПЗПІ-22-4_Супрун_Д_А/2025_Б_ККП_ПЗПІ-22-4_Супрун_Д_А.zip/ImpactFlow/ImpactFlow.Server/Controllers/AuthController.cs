using AutoMapper;
using Core.Enums;
using Core.Helpers;
using Core.Models;
using DAL.Repositories;
using ImpactFlow.Server.ViewModels.Auth;
using ImpactFlow.Server.ViewModels.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ImpactFlow.Server.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly UnitOfWork _unitOfWork;
    private readonly JwtTokenGenerator _jwtTokenGenerator;
    private readonly IMapper _mapper;
    private readonly ILogger<AuthController> _logger;

    public AuthController(UnitOfWork unitOfWork, JwtTokenGenerator jwtTokenGenerator, IMapper mapper, ILogger<AuthController> logger)
    {
        _unitOfWork = unitOfWork;
        _jwtTokenGenerator = jwtTokenGenerator;
        _mapper = mapper;
        _logger = logger;
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        _logger.LogInformation("Attempt to register user with email: {Email}", request.Email);

        var existing = await _unitOfWork.Users.FindAsync(u => u.Email == request.Email);
        if (existing.Any())
        {
            _logger.LogWarning("Registration failed: user with email {Email} already exists", request.Email);
            return Conflict("User with this email already exists.");
        }

        var user = _mapper.Map<User>(request);
        user.PasswordHash = PasswordHasher.HashPassword(request.Password);
        user.RegisteredAt = DateTime.UtcNow;
        user.Role = UserRole.Volunteer;

        await _unitOfWork.Users.AddAsync(user);

        _logger.LogInformation("User {Email} registered successfully with ID: {UserId}", user.Email, user.Id);

        var token = _jwtTokenGenerator.GenerateToken(user);

        return Ok(new AuthResponse
        {
            Token = token,
            UserId = user.Id,
            Role = user.Role.ToString()
        });
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        _logger.LogInformation("Attempt to login with email: {Email}", request.Email);

        var users = await _unitOfWork.Users.FindAsync(u => u.Email == request.Email);
        var user = users.FirstOrDefault();

        if (user == null)
        {
            _logger.LogWarning("Login failed: user not found with email {Email}", request.Email);
            return Unauthorized("Invalid email or password");
        }

        if (!PasswordHasher.VerifyPassword(request.Password, user.PasswordHash))
        {
            _logger.LogWarning("Login failed: invalid password for user {Email}", request.Email);
            return Unauthorized("Invalid email or password");
        }

        var token = _jwtTokenGenerator.GenerateToken(user);

        _logger.LogInformation("User {Email} logged in successfully", request.Email);

        Response.Cookies.Append("jwt", token, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Strict,
            Expires = DateTime.UtcNow.AddMinutes(60)
        });

        return Ok(new { message = "Login successful" });
    }

    [HttpPost("logout")]
    public IActionResult Logout()
    {
        Response.Cookies.Delete("jwt");
        return Ok(new { message = "Logout successful" });
    }

    [HttpGet("profile")]
    [Authorize]
    public async Task<IActionResult> GetCurrentUser()
    {
        _logger.LogInformation("Request to fetch current user profile initiated.");

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(userId))
        {
            _logger.LogWarning("Authorization failed: missing or invalid JWT claim 'NameIdentifier'.");
            return Unauthorized("Unable to determine user identity.");
        }

        _logger.LogInformation("Extracted user ID from token: {UserId}", userId);

        var users = await _unitOfWork.Users.FindAsync(u => u.Id == userId);
        var user = users.FirstOrDefault();

        if (user is null)
        {
            _logger.LogWarning("User with ID {UserId} not found in database.", userId);
            return Unauthorized("User not found.");
        }

        _logger.LogInformation("Successfully retrieved user profile for ID {UserId}. Returning user data.", user.Id);

        var viewModel = _mapper.Map<UserViewModel>(user);

        return Ok(viewModel);
    }
}
